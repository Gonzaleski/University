'''
Name: Arad Soutehkeshan
Student ID: 001347318
Date: Monday, October 9th, 2023
Version: Python 3.9.6

Finding highest number between three numbers entered by the user.
'''
num1 = int(input('Enter your first number: '))
num2 = int(input('Enter your second number: '))
num3 = int(input('Enter your third number: '))

numbers = [num1, num2, num3]

print('The highest number is' , max(numbers))