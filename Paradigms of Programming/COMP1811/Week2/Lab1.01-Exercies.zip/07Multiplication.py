number1_str = input(" First number: ")
number2_str = input("Second number: ")
number1 = int(number1_str)
number2 = int(number2_str)
multiplication = number1* number2
multiplication_str = str(multiplication)
print("Answer:" , multiplication_str)