'''
Name: Arad Soutehkeshan
Student ID: 001347318
Date: Monday, October 23th, 2023
Version: Python 3.9.6

Modifying
'''
thistuple = ("apple", "banana", "cherry")

availFruits = ""

# Replaced XXXX with thistuple
for fruit in thistuple:
  # Replaced XXXX with fruit
  availFruits += fruit

print(availFruits)
