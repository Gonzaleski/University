'''
Name: Arad Soutehkeshan
Student ID: 001347318
Date: Monday, October 23th, 2023
Version: Python 3.9.6

Exercise 6
Write a program that creates a list of 10 employees in the computer department and displays them. You should be one of the employees.
The program should also display the number of employees in the list and give the position of your name.
'''

# Creating the list
employees = ['Arad', 'Amir', 'Asal', 'Mamad', 'Mohsen', 'Akvile', 'Shabnam', 'Hamid', 'Reza', 'Ali']

# Displaying the list
print(employees)

# Displaying the leingth of the list
print(len(employees))

# Displaying my name's index
print(employees.index('Arad'))